
package ili.lithne;

public interface NodeListener
{
   public void nodeEventReceived( NodeEvent event );
}