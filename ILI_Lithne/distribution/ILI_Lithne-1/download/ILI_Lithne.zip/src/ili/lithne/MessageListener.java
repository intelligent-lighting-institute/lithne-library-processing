
package ili.lithne;

public interface MessageListener
{
  public void messageEventReceived( MessageEvent event );
}